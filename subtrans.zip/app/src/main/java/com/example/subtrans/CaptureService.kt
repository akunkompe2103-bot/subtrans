package com.example.subtrans

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import cz.adaptech.tesseract4android.TessBaseAPI
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class CaptureService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "subtrans"
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var rw = 0
    private var rh = 0
    @Volatile private var active = false
    private var worker: Thread? = null
    private var overlay: TextView? = null
    private var stopBtn: TextView? = null
    private var overlayLp: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        val d = (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(0)
        @Suppress("DEPRECATION")
        d.getRealMetrics(dm)
        return dm
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (active) return START_NOT_STICKY

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Sub Translator", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("Sub Translator aktif")
            .setContentText("Menerjemahkan subtitle. Ketuk tombol STOP di layar untuk berhenti.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(1, notif)

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { ui.post { stopSelf() } }
        }, ui)

        active = true
        setupOverlay()
        setupCapture()
        worker = Thread { loop() }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun setupOverlay() {
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            gravity = Gravity.CENTER
            setPadding(dp(16f), dp(8f), dp(16f), dp(8f))
            background = GradientDrawable().apply {
                setColor(Color.argb(200, 0, 0, 0)); cornerRadius = dp(10f).toFloat()
            }
            visibility = View.GONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        overlay = tv; overlayLp = lp
        wm.addView(tv, lp)

        val sb = TextView(this).apply {
            text = "■ STOP"
            setTextColor(Color.WHITE)
            setPadding(dp(14f), dp(8f), dp(14f), dp(8f))
            background = GradientDrawable().apply {
                setColor(Color.argb(220, 200, 30, 30)); cornerRadius = dp(20f).toFloat()
            }
            setOnClickListener { stopSelf() }
        }
        val slp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        slp.gravity = Gravity.TOP or Gravity.END
        slp.x = dp(16f); slp.y = dp(70f)
        stopBtn = sb
        wm.addView(sb, slp)
    }

    private fun setupCapture() {
        val dm = realMetrics()
        rw = dm.widthPixels; rh = dm.heightPixels
        val r = ImageReader.newInstance(rw, rh, PixelFormat.RGBA_8888, 2)
        if (vd == null) {
            vd = projection?.createVirtualDisplay(
                "subtrans", rw, rh, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
        } else {
            vd?.resize(rw, rh, dm.densityDpi)
            vd?.surface = r.surface
        }
        reader?.close()
        reader = r
    }

    private fun showOverlay(text: String?) {
        ui.post {
            val tv = overlay ?: return@post
            val lp = overlayLp ?: return@post
            if (text.isNullOrEmpty()) { tv.visibility = View.GONE; return@post }
            val dm = realMetrics()
            val frac = getSharedPreferences("cfg", MODE_PRIVATE).getInt("region", 25) / 100f
            lp.y = (dm.heightPixels * frac).toInt() + dp(8f)
            lp.width = (dm.widthPixels * 0.9f).toInt()
            tv.text = text
            tv.visibility = View.VISIBLE
            try { wm.updateViewLayout(tv, lp) } catch (_: Exception) {}
        }
    }

    private fun prepareTess(): TessBaseAPI? {
        val dir = File(filesDir, "tessdata"); dir.mkdirs()
        val f = File(dir, "eng.traineddata")
        if (!f.exists() || f.length() < 1000) {
            assets.open("tessdata/eng.traineddata").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        }
        val t = TessBaseAPI()
        if (!t.init(filesDir.absolutePath, "eng")) return null
        t.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK)
        return t
    }

    private fun loop() {
        val tess = try { prepareTess() } catch (e: Exception) { null }
        if (tess == null) { showOverlay("Gagal memuat OCR (data bahasa tidak ditemukan)"); return }
        var lastKey = ""
        var empty = 0
        while (active) {
            try {
                val dm = realMetrics()
                if (dm.widthPixels != rw || dm.heightPixels != rh) {
                    ui.post { try { setupCapture() } catch (_: Exception) {} }
                    Thread.sleep(600); continue
                }
                val bmp = grabRegion()
                if (bmp != null) {
                    tess.setImage(bmp)
                    val raw = tess.utf8Text ?: ""
                    bmp.recycle()
                    val text = raw.replace("\n", " ").replace(Regex("\\s+"), " ").trim()
                    val key = text.lowercase().filter { it.isLetter() }
                    if (key.length < 3) {
                        empty++
                        if (empty >= 3) { showOverlay(null); lastKey = "" }
                    } else {
                        empty = 0
                        if (key != lastKey) {
                            lastKey = key
                            val tr = translate(text)
                            if (tr != null && active) showOverlay(tr)
                        }
                    }
                }
                Thread.sleep(800)
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                try { Thread.sleep(800) } catch (_: InterruptedException) { break }
            }
        }
        tess.recycle()
    }

    /** Ambil bagian bawah layar, ubah teks terang jadi hitam di latar putih (lebih mudah dibaca OCR). */
    private fun grabRegion(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        try {
            val frac = getSharedPreferences("cfg", MODE_PRIVATE).getInt("region", 25) / 100f
            val w = img.width; val h = img.height
            val top = (h * (1f - frac)).toInt()
            val ch = h - top
            val plane = img.planes[0]
            val ps = plane.pixelStride; val rs = plane.rowStride
            val buf = plane.buffer
            buf.position(top * rs)
            val full = Bitmap.createBitmap(rs / ps, ch, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(buf)
            val px = IntArray(w * ch)
            full.getPixels(px, 0, w, 0, 0, w, ch)
            full.recycle()
            for (i in px.indices) {
                val c = px[i]
                val lum = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
                px[i] = if (lum > 190) Color.BLACK else Color.WHITE
            }
            val out = Bitmap.createBitmap(w, ch, Bitmap.Config.ARGB_8888)
            out.setPixels(px, 0, w, 0, 0, w, ch)
            return out
        } catch (e: Exception) {
            return null
        } finally {
            img.close()
        }
    }

    private fun translate(text: String): String? {
        return try {
            val u = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=id&dt=t&q=" +
                URLEncoder.encode(text, "UTF-8"))
            val c = u.openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            val body = c.inputStream.bufferedReader().readText()
            val arr = JSONArray(body).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until arr.length()) sb.append(arr.getJSONArray(i).getString(0))
            sb.toString().trim()
        } catch (e: Exception) {
            null
        }
    }

    override fun onDestroy() {
        active = false
        worker?.interrupt()
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { stopBtn?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { vd?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
